package AssistedProjectsPhase1;

public class Method_CallByValue {

int val=5;

int operation(int val) {
	val =val*100;
	return(val);
}

public static void main(String args[]) {
	Method_CallByValue d = new Method_CallByValue();
	System.out.println("Before operation value of data is "+d.val);
	d.operation(100);
	System.out.println("After operation value of data is "+d.val);
	}
}

