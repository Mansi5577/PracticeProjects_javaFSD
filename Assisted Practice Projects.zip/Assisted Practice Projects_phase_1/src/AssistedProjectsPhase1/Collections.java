package AssistedProjectsPhase1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class Collections {
	public static void main(String[] args) {
		// Array list
		System.out.println("Array List");
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		// printing the list
		System.out.println("Elements of list are: " + list);
		list.remove(3); // removing objects from list
		System.out.println("After Removing 40, List Objects are" + list);
		System.out.println();

		// Linked List
		System.out.println("Linked List");
		LinkedList<Integer> linkedlist = new LinkedList<Integer>();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter length");
		int n = sc.nextInt(); // length of the linked list
		System.out.println("Enter elements of the list:");
		for (int i = 0; i < n; i++) {
			linkedlist.add(sc.nextInt());
		}
		System.out.println("Elements of linked list are: " + linkedlist);
		System.out.println();

		// Vector

		System.out.println("Vector");
		Vector<String> v = new Vector<String>();
		v.add("Mansi");
		v.add("Ritu");
		v.add("Prakhar");
		v.add("Avi");
		System.out.println(v);
		System.out.println();

		// Hash Set
		System.out.println("HashSet");
		HashSet<Integer> set = new HashSet<Integer>();
		set.add(50);
		set.add(70);
		set.add(30);
		System.out.println(set);
		System.out.println();

		// Linked Hash Set
		System.out.println("LinkedHashSet");
		LinkedHashSet<Integer> set1 = new LinkedHashSet<Integer>();
		set1.add(10);
		set1.add(20);
		System.out.println(set1);
	}

}
