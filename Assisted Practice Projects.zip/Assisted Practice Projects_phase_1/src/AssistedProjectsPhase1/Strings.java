package AssistedProjectsPhase1;

public class Strings {

	public static void main(String[] args) {
		String s1="Mansi";
		String s2="Prakhar";
		String s3=new String("Phone");
		String s4=new String("Mansi");
		
		//length of the string
		System.out.println(s1.length());
		
		//substring
		System.out.println(s2.substring(3));
		
		//isEmpty
		System.out.println(s3.isEmpty());
		
		//equals
		System.out.println(s1.equals(s4));
		
		//==
		System.out.println(s1==s2);
		
		//compareTo
		System.out.println(s3.compareTo(s4));
		System.out.println();
		
		//StringBuffer
		StringBuffer s=new StringBuffer("Welcome");
		s.append("to India");
		
		System.out.println(s);

		//insert method
		s.insert(0, 'w');
		System.out.println(s);

		//replace method
		StringBuffer sb=new StringBuffer("Hello");
		sb.replace(0, 2, "hEl");
		System.out.println(sb);

		//delete method
		sb.delete(0, 1);
		System.out.println(sb);
		
		//StringBuilder
		System.out.println("\n");
		System.out.println("Creating StringBuilder");
		StringBuilder sb1=new StringBuilder("Happy");
		sb1.append("Learning");
		System.out.println(sb1);

		System.out.println(sb1.delete(0, 1));

		System.out.println(sb1.insert(1, "Welcome"));

		System.out.println(sb1.reverse());
				
		//conversion	
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		
		String str = "Hello"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              		
	}

}
