package AssistedProjectsPhase1;

public class MethodOverloading {
	
	public void sum(int a,int b) {
		int sum=a+b;
		System.out.println("sum of 2 numbers is: "+sum);
	}
	
	public int sum(int a, int b, int c) {
		return a+b+c;
	}

	public static void main(String[] args) {
		 MethodOverloading m1=new  MethodOverloading();
		 m1.sum(5, 6);
		 int sumof3=m1.sum(8, 7, 10);
		 System.out.println("Sum of 3 numbers is: "+sumof3);

	}

}
