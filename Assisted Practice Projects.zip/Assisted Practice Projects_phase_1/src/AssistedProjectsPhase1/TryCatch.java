package AssistedProjectsPhase1;

import java.util.Scanner;

public class TryCatch {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the values of a and b: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		try {
		System.out.println("Division of 2 numbers is: "+a/b);
		}
		catch(Exception e) {
			System.out.println("You can't divide a number by 0");
			System.out.println(e);
		}
		System.out.println("Program Executed");
		
	}

}
