package AssistedProjectsPhase1;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class Maps {
	public static void main(String[] args){
		  
		  //hash map
		  Map<Integer,String> map=new HashMap<Integer,String>();  
		  map.put(100,"Mansi");  
		  map.put(101,"Prakhar");  
		  map.put(102,"Padmaja");  
		  //Elements can traverse in any order  
		  for(Map.Entry m:map.entrySet()){  
		   System.out.println("Hash Map: "+m.getKey()+" "+m.getValue());  
		  } 
		  System.out.println();
		  
		  
		    //Tree map
			TreeMap<Integer,String> treeMap=new TreeMap<Integer,String>();
			treeMap.put(101, "Steve");
			treeMap.put(102, "Liam");
			treeMap.put(103, "Harry");
			treeMap.put(104, "Jacob");
			System.out.println("Tree Map: "+treeMap);
			}
		  
		 }  
		 
	



