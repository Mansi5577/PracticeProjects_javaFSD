package AssistedProjectsPhase1;

public class Methods {
	public void testmethod(){
		System.out.println("Calling this method to test");
	}
	public static void main(String[] args) {
		//way1
		Methods obj=new Methods();
		obj.testmethod();  
		System.out.println("***************************");
		//way2
		new Methods().testmethod(); 
	}
	



}
