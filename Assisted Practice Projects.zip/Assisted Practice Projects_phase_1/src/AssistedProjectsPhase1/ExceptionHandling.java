package AssistedProjectsPhase1;

public class ExceptionHandling {
	static void getInfo() throws ArithmeticException, ArrayIndexOutOfBoundsException {
		System.out.println(5 / 2);
		int arr[] = { 7 };// arr[0]=7 arr[2]
		System.out.println(arr[2]);

	}


public static void main(String[] args) {
		try {
			getInfo();
			System.out.println("Main Try");
		} 
		catch (ArithmeticException | ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		} 
		finally {
			System.out.println("End of program");
		}
		System.out.println("Terminating..");
}
}
