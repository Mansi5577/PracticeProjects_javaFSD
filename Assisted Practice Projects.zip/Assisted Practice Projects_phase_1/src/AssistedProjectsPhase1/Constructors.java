package AssistedProjectsPhase1;


class typesOfConstructors{
	private int number;
	private int age;
	
	//default constructors
	
	public typesOfConstructors() {
		System.out.println("This is a default constuctor");
	} 
	//Parameterized constructor
	public typesOfConstructors(int number, int age) {
		System.out.println("This is a parameterized constructor");
		this.number = number;
		this.age = age;
		
	}
	void display(){
		System.out.println("Number is: "+number);
		System.out.println("age is: "+age);
	}
	
	
}
public class Constructors {
	public static void main(String[] args) {
		typesOfConstructors obj=new typesOfConstructors();
		typesOfConstructors obj1=new typesOfConstructors(5,20);
		
		obj1.display();
	} 

}
