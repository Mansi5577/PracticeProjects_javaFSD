package AssistedProjectsPhase1;

import java.util.Scanner;

class BankExceptionHandling extends Exception {
	public static int bal = 10000;

	public static boolean checkbal(int amnt) {

		if (amnt <= bal) {
			return true;
		} else {
			return false;
		}
	}
}

public class CustomException {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the amount to be withdrawn");
		int amt = sc.nextInt();

		try {
			if (BankExceptionHandling.checkbal(amt)) {
				System.out.println(
						"Amount withdrawn successfully and balance amount is: " + (BankExceptionHandling.bal - amt));
			} else {
				throw new BankExceptionHandling();
			}
		} catch (BankExceptionHandling b) {
			System.out.println("You do not have that much balance!");
			b.printStackTrace();

		}

	}

}